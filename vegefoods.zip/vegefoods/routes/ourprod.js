var express = require('express');
var router = express.Router();

const ourprodController = require("../controller/ourprodController");
router.get("/ourprod" ,ourprodController.getOurprod);

const vegetableController = require("../controller/vegetableController");
router.get("/vegetable" , vegetableController.getVegetable);
/* GET home page. */
// router.get('/ourprod', function(req, res, next) {
//   res.render('ourprod', { title: 'ourprod' });
// });

module.exports = router;

const db = require("../util/database");

const Ourprod = class Ourprod {
  constructor(id, name,  pic, category, href) {
    this.id = id;
    this.name = name;
    this.pic = pic;
    this.category = category;
    this.href = href;
  }

  static fetchAll() {
    return db.execute("SELECT * FROM ourprod");
  }
};

// TESTING
// const test  = async () => {
//       console.log(await Ourprod.fetchAll());
//     };
//     test();

module.exports = Ourprod;

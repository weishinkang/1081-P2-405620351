const db = require("../util/database");

const Vegetable = class Vegetable {
  constructor(id, name,  pic, price) {
    this.id = id;
    this.name = name;
    this.pic = pic;
    this.price = price;
  }

  static fetchAll() {
    return db.execute("SELECT * FROM vegetable");
  }
};

// TESTING
// const test  = async () => {
//       console.log(await Vegetable.fetchAll());
//     };
//     test();

module.exports = Vegetable;

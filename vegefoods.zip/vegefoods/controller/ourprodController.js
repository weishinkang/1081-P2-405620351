const Ourprod = require("../models/ourprodModel");

exports.getOurprod= async (req, res, next) => {
  let ourprod;
  try {
    const prod= await Ourprod.fetchAll().then(([rows]) => {
        ourprod = rows;
        
      });

      
  } catch (err) {
    console.log(err);
  }
  // res.json(ourprod);
  res.render("ourprod", {
    data: ourprod,
    title: "Ourprod"
  });
};

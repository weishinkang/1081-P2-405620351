const Vegetable = require("../models/vegetableModel");

exports.getVegetable= async (req, res, next) => {
  let vegetable;
  try {
    const vege= await Vegetable.fetchAll().then(([rows]) => {
        vegetable = rows;
        
      });

      
  } catch (err) {
    console.log(err);
  }
  // res.json(vegetable);
  res.render("vegetable", {
    data: vegetable,
    title: "Vegetable"
  });
};
